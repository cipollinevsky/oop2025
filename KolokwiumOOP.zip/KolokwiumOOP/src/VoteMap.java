public class VoteMap extends VoivodeshipMap{

}
