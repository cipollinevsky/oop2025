import java.util.List;

public class ElectionTurn {
    private List<Candidate> candidates;
    private List<Vote> votes;

    public ElectionTurn(List<Candidate> candidates) {
        this.candidates = candidates;
    }

    public void populate(String path){
    }

    public Candidate winner(){
        return null;
    }

    public List runoffCandidates(){
        return null;
    }
}
