public class SelectableMap extends VoivodeshipMap{
    public void select(String name){
    }
}
