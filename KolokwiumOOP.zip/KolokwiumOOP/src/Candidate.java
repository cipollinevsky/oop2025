class Candidate {
    String name;

    public Candidate(String name){
        this.name = name;
    }
}
