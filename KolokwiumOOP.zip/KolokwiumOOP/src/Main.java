public class Main {
    public static void main(String[] args) {
        String path1 = "/home/student/Dokumenty/MartinPolynevskyi307085/KolokwiumOOP/kandydaci.txt";

    }
}