import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Election {
    private List<Candidate> candidates;
    private ElectionTurn firstTurn;
    private ElectionTurn secondTurn;
    private Candidate winner;

    public Election(List<Candidate> candidates, ElectionTurn firstTurn){
        this.candidates = candidates;
        this.firstTurn = firstTurn;
    }

    public ElectionTurn getFirstTurn() {
        return firstTurn;
    }

    public ElectionTurn getSecondTurn() {
        return secondTurn;
    }

    public void setFirstTurn(ElectionTurn firstTurn) {
        this.firstTurn = firstTurn;
    }

    public void setSecondTurn(ElectionTurn secondTurn) {
        this.secondTurn = secondTurn;
    }

    public void setWinner(Candidate winner) {
        this.winner = winner;
    }

    public void populateCandidates(String path){
        try {
            File file = new File(path);
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()){
                this.candidates.add(new Candidate(reader.nextLine()));
            }
        } catch (FileNotFoundException e) {
            System.out.printf("error");
        }
    }

    public void populate(String path){
        populateCandidates(path);
        firstTurn.populate(path);
        firstTurn.winner();
    }
}
