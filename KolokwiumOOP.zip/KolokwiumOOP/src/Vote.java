import java.util.List;
import java.util.Map;

public class Vote {
    private Map<Candidate, Integer> votesForCandidate;
    private List<String> location;

    public Vote(List<String> location){
        this.location = location;
    }

    public static void fromCsvLine(String line){

    }

    public Vote summarize(List<Vote> votes, List<String> location){
        Vote vote = new Vote(location);

        return vote;
    }

    public int votes(Candidate candidate){
        return 0;
    }

    private String percentage(Candidate candidate){
        return "%";
    }

    @Override
    public String toString(){
        return /*name + ": " + votes() + percentage()*/null;
    }

    public static List<Vote> filterByLocation(List<Vote> votes, List<String> location){
        return null;
    }
}
